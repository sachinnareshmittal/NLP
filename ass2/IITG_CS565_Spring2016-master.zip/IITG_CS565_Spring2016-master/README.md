# IITG_CS565_Spring2016
Course Name: Intelligent Systems and Interfaces
